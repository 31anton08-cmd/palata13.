// Запускать ПОСЛЕ `npx cap add android`: npm run patch
const fs=require('fs'),path=require('path');
const man='android/app/src/main/AndroidManifest.xml';
let m=fs.readFileSync(man,'utf8');
if(!m.includes('screenOrientation')){m=m.replace('<activity','<activity\n            android:screenOrientation="sensorLandscape"');fs.writeFileSync(man,m);console.log('Манифест: горизонтальная ориентация включена')}
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const f=walk('android/app/src/main/java').find(x=>x.endsWith('MainActivity.java'));
let j=fs.readFileSync(f,'utf8');
if(!j.includes('WindowInsetsControllerCompat')){
  j=j.replace(/(package [^;]+;)/,'$1\n\nimport androidx.core.view.WindowCompat;\nimport androidx.core.view.WindowInsetsCompat;\nimport androidx.core.view.WindowInsetsControllerCompat;');
  const n=j.replace(/extends BridgeActivity\s*\{\s*\}/,`extends BridgeActivity {
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            c.hide(WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }
}`);
  if(n===j)console.log('MainActivity нестандартный — добавь полноэкранный режим вручную (см. README)');
  else{fs.writeFileSync(f,n);console.log('MainActivity: полноэкранный режим включён')}
}
